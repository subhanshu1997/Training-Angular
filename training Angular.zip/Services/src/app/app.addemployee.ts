import { Component, Input, EventEmitter, Output, OnInit } from "@angular/core";

@Component({
    selector: 'add-emp',
    templateUrl: 'app.addemployee.html'

})
export class AddEmployeeComponent{
    arr:any[]=[]
    empId:number
    empName:string
    empSalary:number
    empDepartment:string
    status:boolean
    empty:boolean=true
    change(){
        this.arr[0]={empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment}
        this.status=!this.status
        this.empty=false
    }
}