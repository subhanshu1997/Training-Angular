import { Component, Input, EventEmitter, Output, SimpleChanges } from "@angular/core";
import { EmployeeService } from "./app.employeeservice";

@Component({
    selector:'show-Employee',
    templateUrl:'app.show-Employee.html'
})
export class ShowEmployee{
    empAll:any[]=[]
    constructor(private service: EmployeeService) {
        
    }
    ngOnInit() : any{
        this.service.getAllEmployee().subscribe((data:any)=>{this.empAll=data})
    }
    @Input()
    emparr:any[]=[]
    @Input()
    status:boolean
    @Input()
    empty:boolean
    ngOnChanges(changes: SimpleChanges):any {
        if(changes['status']){
        if(this.empty==false){
            this.empAll.push(this.emparr[0])
        }
  }}
      deleteEmployee(i){
        for(let data of this.empAll){
            if(data==i){
                this.empAll.splice(i,1)
            }
        }
    }
}
