function addEmployee(){
    
    var name=document.getElementById("empname").value
    var eid=document.getElementById("empid").value
    var arr=new Array
    if(document.getElementById("java").checked)
    arr.push(document.getElementById("java").value)
    if(document.getElementById(".net").checked)
    arr.push(document.getElementById(".net").value)
    if(document.getElementById("salesforce").checked)
    arr.push(document.getElementById("salesforce").value)
    if(document.getElementById("pega").checked)
    arr.push(document.getElementById("pega").value)
    var qualification=document.getElementById("qualification").value
    var option=""
    if(document.getElementById("yes").checked)
    option=document.getElementById("yes").value
    else if(document.getElementById("no").checked)
    option=document.getElementById("no").value
    alert(" Employee Name: "+name+" "+" Employee id: "+eid+" Qualification: "+qualification+" "+"Courses: "+arr+" "+"Online: "+option)
    
}