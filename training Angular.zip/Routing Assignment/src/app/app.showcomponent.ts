import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    selector:'show-emp',
    templateUrl:'app.showcomponent.html'
})
export class ShowComponent implements OnInit{
    data:number
    constructor(private active:ActivatedRoute){}
    ngOnInit(): void {
        this.data=this.active.snapshot.params['id']
    }

}