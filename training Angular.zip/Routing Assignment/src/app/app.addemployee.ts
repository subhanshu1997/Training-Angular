import { Component } from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector:'add-emp',
    templateUrl:'app.add.html',
    styleUrls:['app.add.css']

})
export class AddEmployeeComponent{
    constructor(private router:Router){

    }
    arr:any[]=[
       {empId:1005,empPassword:"hello123"}
    ]
    empId:number
    empPassword:string
   
    login():any{
        if(this.arr[0].empId==this.empId && this.arr[0].empPassword==this.empPassword){
            this.router.navigate(['show',this.empId])
        } 
        else{
            alert("Please enter valid id and password")
        }      
    }
    
}