﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {AddEmployeeComponent} from './app.addemployee';
import {FormsModule} from '@angular/forms'
import {RouterModule,Routes} from '@angular/router'
import { ShowComponent } from './app.showcomponent';
const routes:Routes=[
    {path:'show/:id',component:ShowComponent},
    {path:'',component:AddEmployeeComponent}
]
@NgModule({
    imports: [
        BrowserModule,FormsModule,
        RouterModule.forRoot(routes)
        
    ],
    declarations: [
        AppComponent,
        AddEmployeeComponent,
        ShowComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }