import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product} from './product';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:9090/';
  user1:any;
  object={
    "user":"101",
    "products":"525"
    

}
  object1: any;
  object2:any;
  constructor(private http: HttpClient) { }
 
  createWishList(product: Product): Observable<any> {
     
    return this.http.post<any>(`${this.baseUrl}` + `/new`, this.object );
  }

  deleteCustomer(productId: any): Observable<any> {
    let object1={
      "userId":"103",
      "productId": productId
  }
    return this.http.post(`${this.baseUrl}/remove`,this.object1);
  }


  addtoCart(amount:any,productId: any): Observable<any> {
    let object2={
      "userId":"103",
      "productId": productId,
      "amount":amount
  }
    return this.http.post(`${this.baseUrl}/addProductToNewCart/create`,this.object2);
  }




  getproductsList(): Observable<any> {
    let user1={
      "userid":"101"
    }
    return this.http.get(`${this.baseUrl}/getWishlist`,this.user1);
  }

}
