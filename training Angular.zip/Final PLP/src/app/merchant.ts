export class Merchant{
    firstname: string;
    lastname: string;
    company: string;
    emailid: string;
    mobileno: number;
    password: string;
    photo: string;
    rating: number;
}