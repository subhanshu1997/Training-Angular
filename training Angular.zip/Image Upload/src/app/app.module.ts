﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {HttpClientModule} from '@angular/common/http'
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import{FileUploadModule} from 'ng2-file-upload'


@NgModule({
    imports: [
        BrowserModule, BrowserModule,HttpClientModule,FormsModule,FileUploadModule
        
    ],
    declarations: [
        AppComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }