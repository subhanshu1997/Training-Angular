﻿import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent implements OnInit{  
 
    uploader: FileUploader; 
    ngOnInit(): void {
      const headers = [{name: 'Accept', value: 'application/json'}];
      this.uploader = new FileUploader({url: 'http://localhost:5000/api/files', autoUpload: false,headers: headers});
      this.uploader.onCompleteAll = () => alert('File uploaded');

    }
    Upload(){
      this.uploader.uploadAll()
    }
    onFileChanged(event) {
      console.log( event.target.files[0].name);
      }
  }
