import { Component, OnInit } from "@angular/core";
import { EmployeeService } from "./app.employeeservice";
import { ActivatedRoute} from "@angular/router";

@Component({
    selector:'show-employee',
    templateUrl:'show-employee.html'
})
export class ShowEmployeeComponent implements OnInit{
    empAll:any[]=[]
constructor(private service:EmployeeService,private active:ActivatedRoute){

}
data:any
empId:number


ngOnInit(): void {
    // console.log("Show Employee init method")
    // this.empAll.push(this.service.getAllEmployee())
    this.empAll=this.service.getAllEmployee()
    this.data=this.active.snapshot.params['id']
    // console.log(this.service.getAddedArray())
    // if(this.service.emparr.length!=0){
    //     this.empAll.push(this.service.emparr[0])
    // }
    // console.log(this.service.getAddedArray());
    // this.service.getAddedArray().subscribe((data:any)=>{console.log(data)})
    // this.service.getMessages().subscribe((data:any)=>{console.log(data)})
}

}