﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {FormsModule} from '@angular/forms'
import {RouterModule,Routes} from '@angular/router'
import { AddUser } from './controller/app.adduser';
import { Withdraw } from './controller/app.withdraw';
import { Deposit } from './controller/app.deposit';
import { Transfer } from './controller/app.transfer';
import { Find } from './controller/app.find';
import { Delete } from './controller/app.delete';
import { Update } from './controller/app.update';
import { View } from './controller/app.view';
import {HttpClient,HttpClientModule} from '@angular/common/http'
const routes:Routes=[
    // {path:'show/:id',component:ShowComponent},
    // {path:'',component:AddEmployeeComponent}\
    {path:'',component:AddUser},
    {path:'create',component:AddUser},
    {path:'withdraw',component:Withdraw},
    {path:'deposit',component:Deposit},
    {path:'transfer',component:Transfer},
    {path:'find',component:Find},
    {path:'delete',component:Delete},
    {path:'update',component:Update},
    {path:'view',component:View}

]
@NgModule({
    imports: [
        BrowserModule,FormsModule,
        RouterModule.forRoot(routes),
        HttpClientModule
        
    ],
    declarations: [
        AppComponent,
        AddUser,
        Withdraw,
        Deposit,
        Transfer,
        Find,
        Delete,
        Update,
        View
		],
    providers: [ HttpClient],
    bootstrap: [AppComponent]
})

export class AppModule { }