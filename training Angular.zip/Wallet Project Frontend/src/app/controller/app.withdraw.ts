import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import { Message } from "../models/message";

@Component({
    selector:'withdraw',
    templateUrl:'app.withdraw.html'
})
export class Withdraw{
    mobile:number
    amount:number
    status:boolean=true
    message:Message
    constructor(private service:AccountService){}
    withdraw(){
        this.service.withdraw(this.mobile,this.amount).subscribe(
            res=>this.message=res
        )
        this.status=true
    }
}