import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import { Message } from "../models/message";

@Component({
    selector:'update',
    templateUrl:'app.update.html'
})
export class Update{
    mobile:number
    aid:number
    accountholder:string
    balance:number
    status:boolean=false
    message:Message
    constructor(private service:AccountService){
    }
    update(){
        this.service.update(this.mobile,this.aid,this.accountholder,this.balance).subscribe(
            res=>this.message=res
        )
        this.status=true
    }

}