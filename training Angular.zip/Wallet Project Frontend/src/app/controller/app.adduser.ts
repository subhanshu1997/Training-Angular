import { Component, OnInit } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import { Account } from "../models/Account";
import { Message } from "../models/message";

@Component({
    selector:'adduser',
    templateUrl:'app.adduser.html'
})
export class AddUser{
    mobile:number
    aid:number
    accountholder:string
    balance:number
    status:boolean=false
    message:Message
    constructor(private service:AccountService){

    }
    addAccount(){
        let account:Account={
            mobile:this.mobile,
            aid:this.aid,
            accountholder:this.accountholder,
            balance:this.balance
        }
        console.log(account)
        this.service.addAccount(account).subscribe(
            res=>this.message=res
        )
        this.status=true
    }

}