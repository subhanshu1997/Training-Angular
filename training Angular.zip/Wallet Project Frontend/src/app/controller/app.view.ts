import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";

@Component({
    selector:'view',
    templateUrl:'app.view.html'
})
export class View{
    constructor(private service:AccountService){}
    status:boolean=false
    accounts: Account[]=[]
    isEmpty=true
    view(){
        this.service.view().subscribe(
            res=> {this.accounts = res
                this.status=true
        console.log(this.accounts.length)
        if(this.accounts.length>0){
            this.isEmpty=false
        }
        else{
            this.isEmpty==true
        }
            }
        )
    }
    
}