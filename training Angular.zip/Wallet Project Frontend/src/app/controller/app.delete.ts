import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import { Message } from "../models/message";

@Component({
    selector:'delete',
    templateUrl:'app.delete.html'
})
export class Delete{
    constructor(private service:AccountService){
    }
    mobile:number
    message:Message
    status:boolean=false
    delete(){
        this.service.delete(this.mobile).subscribe(
            res=>this.message=res
        )
        this.status=true
    }
}