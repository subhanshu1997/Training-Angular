import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import { Message } from "../models/message";

@Component({
    selector:'deposit',
    templateUrl:'app.deposit.html'
})
export class Deposit{
    mobile:number
    amount:number
    status:boolean=false
    message:Message
    constructor(private service:AccountService){}
    deposit(){
        this.service.deposit(this.mobile,this.amount).subscribe(
            res=>this.message=res
        )
        this.status=true
    }
}