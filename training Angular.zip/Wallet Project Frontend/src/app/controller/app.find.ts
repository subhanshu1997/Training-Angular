import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import {Account} from "./../models/Account"

@Component({
    selector:'find',
    templateUrl:'app.find.html'
})
export class Find{
    mobile:number
    account: Account;
    status:boolean=false
    isEmpty:boolean=true
    constructor(private service:AccountService){}
    find(){
        this.service.find(this.mobile).subscribe(
            res=>{ this.account = res
                this.status=true
                if(this.account.aid){
                    this.isEmpty=false
                }
                else{
                    this.isEmpty=true
                }
            }
            
        )
    }

}