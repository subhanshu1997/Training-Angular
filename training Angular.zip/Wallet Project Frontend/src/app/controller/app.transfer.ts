import { Component } from "@angular/core";
import { AccountService } from "../service/app.accountservice";
import { Message } from "../models/message";

@Component({
    selector:'transfer',
    templateUrl:'app.transfer.html'
})
export class Transfer{
    mobile1:number
    mobile2:number
    amount:number
    message:Message
    status:boolean=false
    constructor(private service:AccountService){}
    transfer(){
        this.service.transfer(this.mobile1,this.mobile2,this.amount).subscribe(
            res=>this.message=res
        )
        this.status=true
    }

}