export class Account{
    mobile:number
    aid:number
    accountholder:String
    balance:number
}