export class Message{
    error:boolean
    message:String
}