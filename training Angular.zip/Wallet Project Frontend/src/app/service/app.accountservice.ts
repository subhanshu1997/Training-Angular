import { Injectable } from "@angular/core";
import {HttpClient,HttpClientModule} from '@angular/common/http'
import { Account } from "../models/Account";
import { Observable, observable } from "rxjs";
import{Message} from "../models/Message"

@Injectable({
    providedIn:'root'
})

export class AccountService{
    constructor(private http:HttpClient){

    }
    account:Account
    baseURl='http://localhost:3000/accounts'
    result:any
addAccount(account:Account):Observable<Message>{
    return this.http.post<Message>(this.baseURl+'/new',account)
}
delete(mobile:number):Observable<Message>{
return this.http.delete<Message>(this.baseURl+'/delete'+'/'+mobile)
}
deposit(mobile:number,amount:number):Observable<Message>{
    let object={
        mobileno:mobile,
        amount:amount
    }
    return this.http.post<Message>(this.baseURl+'/deposit',object)
}
find(mobile:number):Observable<Account>{
     return this.http.get<Account>(this.baseURl+'/find/'+mobile);
}
transfer(mobile1:number,mobile2:number,amount:number):Observable<Message>{
    let object={
        from:mobile1,
        to:mobile2,
        amount:amount
    }
    return this.http.post<Message>(this.baseURl+'/transfer',object)
}
withdraw(mobile:number,amount:number):Observable<Message>{
    let object={
        mobileno:mobile,
        amount:amount
    }
    return this.http.post<Message>(this.baseURl+'/withdraw',object)

}
update(mobile:number,aid:number,accountholder:string,balance:number):Observable<Message>{
    let object={
        mobile:mobile,
        aid:aid,
        accountholder:accountholder,
        balance:balance
    }
    return this.http.put<Message>(this.baseURl+'/update',object)

}
view():Observable<any>{
    return this.http.get<any>(this.baseURl+'/getAll')
}

} 