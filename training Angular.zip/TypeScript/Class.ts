class Employee{
    empId:number
    empName:string
    empSalary:number
    empStatus:boolean
printAllEmployee():any{
    console.log(this.empId+" "+this.empName+" "+this.empSalary+" "+this.empStatus)
}
}
let employee=new Employee()
employee.empId=1
employee.empName="Subhanshu"
employee.empSalary=50000
employee.empStatus=true
employee.printAllEmployee()

