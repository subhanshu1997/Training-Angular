import {Product} from "./Assignment"
let arr:Product[]=[
    {pId:101,pName:"Dabur",pCost:500},
    {pId:102,pName:"Parle",pCost:1000},
    {pId:103,pName:"Parachute",pCost:1500}
];
arr.push({pId:104,pName:"Britannia",pCost:6000})
console.log(arr)
arr.splice(1,1)
console.log(arr)
for(let i in arr){
    if(arr[i].pId==103)
    console.log(i)
}