// let addNumber=(x:number,y:number):number=>{
//     return x+y
// }
// let sumOfNumber:number=addNumber(20,30)
// console.log(sumOfNumber)
// let addNumber=(...num)=>{
//     let sum:number=0
//     for(let data in num)
//         sum=sum+num[data]
//     return sum
// }
// let sumOfNumber=addNumber(20,30,20)
// console.log(sumOfNumber)
let addNumber=(...num)=>{
    let sum=0
    for(let data of num)
        sum=sum+data
    return sum
}
let sumOfNumber=addNumber(20,30,20)
console.log(sumOfNumber)