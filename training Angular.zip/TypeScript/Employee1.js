"use strict";
exports.__esModule = true;
var empAll = [
    { empId: 1001, empName: "ABCD", empSalary: 1000, empStatus: true },
    { empId: 1002, empName: "ABCD", empSalary: 5000, empStatus: true },
    { empId: 1003, empName: "ABCD", empSalary: 10000, empStatus: true }
];
empAll.push({ empId: 1004, empName: "ABCD", empSalary: 10000, empStatus: true });
empAll.splice(1, 1);
for (var _i = 0, empAll_1 = empAll; _i < empAll_1.length; _i++) {
    var data = empAll_1[_i];
    console.log(data.empId + " " + data.empName + " " + data.empSalary + " " + data.empStatus);
}
