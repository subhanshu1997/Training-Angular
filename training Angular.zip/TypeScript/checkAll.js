// let addNumber=(x:number,y:number):number=>{
//     return x+y
// }
// let sumOfNumber:number=addNumber(20,30)
// console.log(sumOfNumber)
// let addNumber=(...num)=>{
//     let sum:number=0
//     for(let data in num)
//         sum=sum+num[data]
//     return sum
// }
// let sumOfNumber=addNumber(20,30,20)
// console.log(sumOfNumber)
var addNumber = function () {
    var num = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        num[_i] = arguments[_i];
    }
    var sum = 0;
    for (var _a = 0, num_1 = num; _a < num_1.length; _a++) {
        var data = num_1[_a];
        sum = sum + data;
    }
    return sum;
};
var sumOfNumber = addNumber(20, 30, 20);
console.log(sumOfNumber);
