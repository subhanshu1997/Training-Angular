export class IEmployee{
    empId:number
    empName:string
    empSalary:number
    empStatus:boolean
}