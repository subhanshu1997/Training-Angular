import {IEmployee} from './Employee'
let empAll:IEmployee[]=[
    {empId:1001,empName:"ABCD",empSalary:1000,empStatus:true},
    {empId:1002,empName:"ABCD",empSalary:5000,empStatus:true},
    {empId:1003,empName:"ABCD",empSalary:10000,empStatus:true}
];
empAll.push({empId:1004,empName:"ABCD",empSalary:10000,empStatus:true})
empAll.splice(1,1)
empAll.spl
for(let data of empAll){
    console.log(data.empId+" "+data.empName+" "+data.empSalary+" "+data.empStatus)
}