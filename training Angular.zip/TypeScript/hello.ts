let empId:number=1001
let empName:string="Abcd"
let empSalary:number=10002.01
let empStatus:boolean=true
console.log(`Employee name is ${empName} Employee Id is ${empId}`)