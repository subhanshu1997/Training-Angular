var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.printAllEmployee = function () {
        console.log(this.empId + " " + this.empName + " " + this.empSalary + " " + this.empStatus);
    };
    return Employee;
}());
var employee = new Employee;
employee.empId = 1;
employee.empName = "Subhanshu";
employee.empSalary = 50000;
employee.empStatus = true;
employee.printAllEmployee();
