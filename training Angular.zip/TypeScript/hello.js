var empId = 1001;
var empName = "Abcd";
var empSalary = 10002.01;
var empStatus = true;
console.log("Employee name is " + empName + " Employee Id is " + empId);
