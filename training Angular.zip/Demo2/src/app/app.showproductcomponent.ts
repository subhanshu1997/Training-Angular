import { Component } from "@angular/core";

@Component({
    selector:'show-product',
    templateUrl:'show-product.html'
})
export class ShowProductComponent{

}