import { Component } from "@angular/core";

@Component({
    selector:'add-product',
    templateUrl:'add-product.html'
})
export class AddProductComponent{

}