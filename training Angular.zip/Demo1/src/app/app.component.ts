﻿import { Component } from '@angular/core';
import { AddEmployeeComponent } from './app.addemployee';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent { 

}