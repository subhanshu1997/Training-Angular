import { Component, Input, EventEmitter, Output } from "@angular/core";

@Component({
    selector:'show-Employee',
    templateUrl:'app.show-Employee.html'
})
export class ShowEmployee{
    @Input()
    inchild:string
    @Output()
    notify:EventEmitter<String>=new EventEmitter<String>()
    callingParent(){
        this.notify.emit("Child calling parent")
    }
}
