import { Component,Input, EventEmitter, Output} from "@angular/core";

@Component({
    selector:'add-emp',
    templateUrl:'app.addemployee.html'

})
export class AddEmployeeComponent{
    @Input()
    inchild:string
    @Output()
    notify:EventEmitter<string>=new EventEmitter<string>()
    callingParent():any{
        this.notify.emit("From child data send")
    }
}