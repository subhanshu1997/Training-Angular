﻿import { Component} from '@angular/core';
import { AddEmployeeComponent } from './app.addemployee';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})
export class AppComponent{
    // ngDoCheck(): void {
    //     console.log("Do check called")
    // }
    // constructor(){
    //     console.log("Constructor Called")
    // }
    // ngOnInit(): void {
    //     console.log("OnInit Called")
    // } 
    // ngOnDestroy(){
    //     console.log("Destroyed Component")
    // }
    empName:string="Capgemini"
    empShow:string="Showing employee"
    message:string
    message1:string
    getDataFromChild(msg){
        this.message=msg
    }
    getDataFromChild1(msg){
        this.message1=msg
    }
}